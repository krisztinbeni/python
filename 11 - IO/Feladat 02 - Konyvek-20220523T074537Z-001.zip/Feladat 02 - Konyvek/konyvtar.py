from konyvio import *
from konyv import *
from konyvtar import *
from typing import *

class Konyvtar:

    def __init__(self) -> None:
        super().__init__()
