from varosio import VarosIO
from varos import Varos
from typing import *

class Varosok:

# 2.f
    @staticmethod
    def megyejoguVarosok(megyejog: List[Varos]) -> List[Varos]:
        

        VarosIO.write("megyejoguvarosok.txt", megyejog)

# 3.f
    @staticmethod
    def nepessegErtekekkozott(nepessegek: List[Varos]) -> List[Varos]:
        

        VarosIO.write("nepesseg.txt", nepessegek)

# 4.f
    @staticmethod
    def nagyteruletuVarosok(nagyterulet: List[Varos]) -> List[Varos]:
        

        VarosIO.write("nagyteruletek.txt", nagyterulet)

# 5.f
    @staticmethod
    def bekesmegyeTelepules(bekestelepules: List[Varos]) -> List[Varos]:
        

        VarosIO.write("bekes.txt", bekestelepules)

# 6.f
    @staticmethod
    def megyeEsTerulet(megyeterulet: List[Varos]) -> List[Varos]:
        

        VarosIO.write("megyeterületek.txt", megyeterulet)